package com.emr.www;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicalChatEmrApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicalChatEmrApplication.class, args);
	}

}
