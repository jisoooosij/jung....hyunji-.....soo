package com.emr.www.repository.nurse;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface NurseRepository extends JpaRepository<NurseEntity, Long> {
    Optional<NurseEntity> findByLicenseIdAndPassword(String licenseId, String password);
}
