package com.emr.www.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

	@Autowired
	private EmployeeService employeeService; // 서비스 클래스 주입

	@GetMapping("/doctor/main")
	public String showDoctorMainPage() {
		return "doctor/DoctorMain"; // "WEB-INF/views/doctor/DoctorMain.jsp"를 의미
	}

	@GetMapping("/nurse/main")
	public String showNurseMainPage() {
		return "nurse/NurseMain"; // "WEB-INF/views/nurse/NurseMain.jsp"를 의미
	}
}
